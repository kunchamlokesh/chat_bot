from django.apps import AppConfig


class RasawebConfig(AppConfig):
    name = 'rasaweb'
