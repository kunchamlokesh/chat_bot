# website/rasaweb/utils/google_search.py
# __author__='Lokesh Kuncham'
# import requests
# import ast
# session = requests.Session()
# session.auth = ("admin", "123456")
#
# response = session.get('http://127.0.0.1:8000/api/get_answer/{}'.format("what is"))
# print(response.text)
# print(ast.literal_eval(response.text)[0]['answer'])